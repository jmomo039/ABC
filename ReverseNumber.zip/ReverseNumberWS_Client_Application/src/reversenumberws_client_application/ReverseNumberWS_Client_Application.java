/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package reversenumberws_client_application;

import static java.lang.Integer.reverse;

/**
 *
 * @author dadas
 */
public class ReverseNumberWS_Client_Application {

    public static void main(String[] args) {
        try {
            int number = 1234;
            int reversed = reverseNumber(number);
            System.out.println("Reversed Number = " + reversed);
        } catch (Exception ex) {
            System.out.println("Exception: " + ex);
        }
    }

    private static int reverseNumber(int number) {
        org.me.reversenumber.ReverseNumberWS_Service service = new org.me.reversenumber.ReverseNumberWS_Service();
        org.me.reversenumber.ReverseNumberWS port = service.getReverseNumberWSPort();
        return port.reverseNumber(number);
    }
}
